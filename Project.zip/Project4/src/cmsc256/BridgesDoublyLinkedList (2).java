package cmsc256;

import bridges.base.DLelement;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;


public class BridgesDoublyLinkedList<E> {


    //Instance variables

    private DLelement<E> head; // Pointer to list header
    private DLelement<E> tail; // Pointer to last element
    private DLelement<E> curr;      // Access to current element
    private int listSize;           // Size of list

    //Constructor
    public BridgesDoublyLinkedList() {
        head = new DLelement<>();
        tail = new DLelement<>();
        head.setNext(tail);
        tail.setPrev(head);
        curr = tail;
        listSize = 0;

    }

    //clear method
    public void clear() {
        head.setNext(tail);
    }

    //insert method
    public boolean insert(E it) {

        curr = new DLelement<>(it, curr, curr.getPrev());
        curr.getPrev().setNext(curr);
        curr.getNext().setPrev(curr);
        listSize++;
        return true;
    }

    //append method
    public boolean append(E it) {
        tail.setPrev(new DLelement<>(it, tail, tail.getPrev()));
        tail.getPrev().getPrev().setNext(tail.getPrev());
        if (curr == tail)
            curr = tail.getPrev();
        listSize++;
        return true;
    }

    //remove method
    public E remove() {
        if (curr == tail)
            return null;
        E it = curr.getValue(); //??
        curr.getPrev().setNext(curr.getNext());
        curr.getNext().setPrev(curr.getPrev());
        curr = curr.getNext();
        listSize--;
        return it;
    }

    //move to start method (move current position to start)
    public void moveToStart() {
        curr = head;
    }

    //move to end method (move current position to end)
    public void moveToEnd() {
        curr = tail;
    }

    //Move the current position one step left, no change if already at beginning
    public void prev() {
        if (curr.getPrev() != head)
            curr = curr.getPrev();
    }

    //next method
    public void next() {
        if (curr.getNext() != tail) {
            curr = curr.getNext();
        }

    }

    //length method
    public int length() {
        return listSize;
    }

    //currPos method
    public int currPos() {
        DLelement<E> value = curr;
        int i = 0;
        moveToStart();
        while (curr != value) {
            next();
            i++;
        }
        //curr = value;
        return i;

    }

    //moveToPos method
    public boolean moveToPos(int pos) {
        if ((pos > listSize) || (pos < 0)) {
            return false;
        } else {
            moveToStart();
            for (int i = 0; i < pos; i++) {
                next();

            }
            return true;
        }
    }

    //isAtEnd method
    public boolean isAtEnd() {
        return curr == tail;

    }

    //getValue method
    public E getValue() {
        return curr.getValue();
    }

    ///isEmpty method
    public boolean isEmpty() {
        return curr.getValue() == null;
    }

    //toString method
   /* public String toString() {
        StringBuilder result = new StringBuilder();
        moveToStart();
        while (!isAtEnd()) {
            result.append(getValue());
            next();

        }
        return result.toString();
    }
*/

    //Main method
    public static void main(String[] args) throws IOException, RateLimitException {

        //test all of the methods in the interface within main method of BridgesDoublyLinkedList class


        //  Bridges bridges = new Bridges(4, "rizviab",
        //  "961594613846");

        // BridgesDoublyLinkedList<String> Plants = new BridgesDoublyLinkedList<>();

        /*create 20 elements
        Plants.append("Lavender");
        Plants.append("Rose");
        Plants.append("Sunflower");
        Plants.append("Peony");
        Plants.append("Gardenias");
        Plants.append("Geranium");
        Plants.append("Marigold");
        Plants.append("Lily");
        Plants.append("Honeysuckle");
        Plants.append("Aloe");
        Plants.append("Fern");
        Plants.append("Cactus");
        Plants.append("Orchid");
        Plants.append("Bamboo");
        Plants.append("Dandelion");
        Plants.append("Cannabis");
        Plants.append("Bonsai");
        Plants.append("Jade");
        Plants.append("Daffodil");
        Plants.append("Dahlia");
*/
        //System.out.println(Plants.toString());


        //bridges.setDataStructure(Plants.head);
        // bridges.visualize();

    }
}








